from dotenv import load_dotenv
load_dotenv()

import os
import base64
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import openai
from openai import OpenAI
import re

def clean_script_for_tts(script):
    return re.sub(r"\\[.*?\\]", "", script)

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

import requests

ELEVEN_API_KEY = os.getenv("ELEVEN_API_KEY")
VOICE_ID = "EXAVITQu4vr4xnSDxMaL"  # Default voice

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")

# Remove [bracketed] lines before TTS
def strip_stage_directions(text):
    return re.sub(r"\[.*?\]", "", text)

class TopicRequest(BaseModel):
    topic: str

@app.get("/", response_class=HTMLResponse)
async def serve_home():
    with open("static/frontend.html", "r") as f:
        html_content = f.read()
    return HTMLResponse(content=html_content, status_code=200)

@app.post("/generate")
async def generate_podcast(data: TopicRequest):
    prompt = f"Create a 1-minute podcast script about: {data.topic} \n\n make use of [Intro Music] [Background Music Starts] [Outro Music]"

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=500
    )

    script = response.choices[0].message.content.strip()
    clean_script = strip_stage_directions(script)

    # Generate audio with ElevenLabs
    headers = {
        "xi-api-key": ELEVEN_API_KEY,
        "Content-Type": "application/json"
    }
    tts_payload = {
        "text": clean_script_for_tts(clean_script),
        "model_id": "eleven_monolingual_v1",
        "voice_settings": {
            "stability": 0.7,
            "similarity_boost": 0.75
        }
    }

    tts_url = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}"
    audio_response = requests.post(tts_url, headers=headers, json=tts_payload)

    if audio_response.status_code != 200:
        return {"error": "TTS generation failed."}

    audio_base64 = base64.b64encode(audio_response.content).decode('utf-8')

    return {
        "script": script,
        "audio_base64": audio_base64
    }
