Install dependencies using
 - pip install -r requirements.txt

Run the app using 
- uvicorn main:app --reload